cd C:\Collector\Sentinel
.\export_logs.ps1 -OutputPath "C:\Collector\Sentinel\Logs"