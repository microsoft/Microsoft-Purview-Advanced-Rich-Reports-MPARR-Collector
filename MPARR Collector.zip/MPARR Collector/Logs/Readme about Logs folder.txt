In this folder MPARR_Collector.ps1 generate a timestamp.json file every time that is executed, this permit to download only the delta of the information from Office 365 Management API.

Additionally, if an error ocurr, the data collected is stored to be imported in Logs Analytics later.