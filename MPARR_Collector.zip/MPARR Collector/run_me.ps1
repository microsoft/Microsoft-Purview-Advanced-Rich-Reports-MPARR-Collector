cd C:\Collector\Sentinel
.\MPARR_Collector.ps1 -OutputPath "C:\Collector\Sentinel\Logs"